package com.example.SistemaDePartido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDePartidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDePartidoApplication.class, args);
	}

}
