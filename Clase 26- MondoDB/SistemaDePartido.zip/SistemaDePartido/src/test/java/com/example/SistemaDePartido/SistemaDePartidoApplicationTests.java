package com.example.SistemaDePartido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaDePartidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
