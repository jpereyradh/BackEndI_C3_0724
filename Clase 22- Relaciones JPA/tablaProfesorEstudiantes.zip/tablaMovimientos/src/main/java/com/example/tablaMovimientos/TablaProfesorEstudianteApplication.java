package com.example.tablaMovimientos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TablaProfesorEstudianteApplication {

	public static void main(String[] args) {
		SpringApplication.run(TablaProfesorEstudianteApplication.class, args);
	}

}
